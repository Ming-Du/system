
#include "mogo_curl.h"
#include "mogo_json.h"
#include "md5.h"

MogoCurl::MogoCurl()
{}

MogoCurl::~MogoCurl()
{
	curl_easy_cleanup(m_curl_handle);
	curl_global_cleanup();
}

CURLcode MogoCurl::Init()
{
	CURLcode error;
	curl_global_init(CURL_GLOBAL_ALL);
	m_curl_handle = curl_easy_init();
	curl_easy_setopt(m_curl_handle, CURLOPT_WRITEFUNCTION, write_data);
}

CURLcode MogoCurl::Get(const std::string &url, std::string &rstr)
{
	std::stringstream out;
	curl_easy_setopt(m_curl_handle, CURLOPT_WRITEDATA, &out);
	CURLcode res = curl_easy_perform(m_curl_handle);
	if(res != CURLE_OK)
	{
		return res;
	}
	rstr = out.str();
	return res;
}

CURLcode MogoCurl::Post(const std::string &url, const std::string &pstr, std::string &rstr)
{
	curl_easy_setopt(m_curl_handle, CURLOPT_URL, url.c_str());
	curl_easy_setopt(m_curl_handle, CURLOPT_POST, 1);
	curl_easy_setopt(m_curl_handle, CURLOPT_POSTFIELDS, pstr.c_str());
	curl_easy_setopt(m_curl_handle, CURLOPT_READFUNCTION, NULL);
	curl_easy_setopt(m_curl_handle, CURLOPT_NOSIGNAL, 1);
	curl_easy_setopt(m_curl_handle, CURLOPT_CONNECTTIMEOUT_MS, 200);
	curl_easy_setopt(m_curl_handle, CURLOPT_TIMEOUT, 200);

	curl_easy_setopt(m_curl_handle, CURLOPT_FOLLOWLOCATION, 1);
	curl_easy_setopt(m_curl_handle, CURLOPT_TCP_KEEPALIVE, 1L);  // enable TCP keep-alive for this transfer 
	curl_easy_setopt(m_curl_handle, CURLOPT_TCP_KEEPIDLE, 120L);	// keep-alive idle time to 120 seconds 
	curl_easy_setopt(m_curl_handle, CURLOPT_TCP_KEEPINTVL, 60L);

	struct curl_slist* headers = NULL;
	headers = curl_slist_append(headers, "Content-Type:application/json;charset=UTF-8");
	curl_easy_setopt(m_curl_handle, CURLOPT_HTTPHEADER, headers);
	curl_easy_setopt(m_curl_handle, CURLOPT_POST, 1);// set post

	MemoryStruct oDataChunk;
	curl_easy_setopt(m_curl_handle, CURLOPT_WRITEDATA, &oDataChunk);
	curl_easy_setopt(m_curl_handle, CURLOPT_WRITEFUNCTION, write_data);
	CURLcode res = curl_easy_perform(m_curl_handle);
	rstr = oDataChunk.memory;
	std::cout << "response str is " << rstr << " and res is "<< res << std::endl;
	return res;
}

bool MogoCurl::GetUpdateFileList(const std::string &update_url, const std::string &mac_addr, const std::string &SN, std::list<std::string> &file_list)
{
	Json::Value root;
	Json::FastWriter fast_writer;
	root["sn"]=SN;
	root["mac"] = mac_addr;
	std::string pstr = fast_writer.write(root);
	std::cout << "post str is " << pstr << std::endl;
	std::string rstr;
	if(Post(update_url, pstr, rstr) != CURLE_OK) 
	{
		return false;
	}
	std::cout << "rstr is " << rstr << " *******" << std::endl;
	MyJson pJson;
	if(!pJson.parse(rstr)) 
	{
		return false;
	}

	int errcode = -1;
	if(!pJson.getInt("errcode", errcode) || errcode!=0) 
	{
		return false;
	}
	Json::Value arrayObj;
	if(!pJson.getObject("data", arrayObj)) 
	{
		return false;
	}
	MyJson pArrayJson(arrayObj);
	int list_size = pArrayJson.getSize();
	for(size_t i=0; i<list_size; i++)
	{
		Json::Value obj = pJson.getObjectIndex("data", i);
		MyJson pObjJson(obj);
		std::string file_path;
		if(!pObjJson.getString("filepath", file_path)) 
		{
			return false;
		}
		std::string md5_str;
		if(!pObjJson.getString("md5", md5_str)) 
		{
			return false;
		}
		int update;
		if(!pObjJson.getInt("update", update)) 
		{
			return false;
		}
		if(access(file_path.data(), NULL)!=0 || MD5().fileDigest(file_path)!=md5_str)
		{
			file_list.emplace_back(file_path);
			//size_t pos = file_path.find_last_of("/");
			//file_list.emplace_back(file_path.substr(pos, file_path.size()));
		}
	}
	return true;
}       
bool MogoCurl::DownloadFileContent(const std::string &download_url, const std::string check_url, const std::string &SN, const std::string &mac_addr, const std::string &fileName)
{
	Json::Value root;
	Json::FastWriter fast_writer;
	root["sn"]=SN;
	root["mac"] = mac_addr;
	root["filepath"] = fileName;
	std::string pstr = fast_writer.write(root);
	std::string rstr;
	if(Post(download_url, pstr, rstr) != CURLE_OK) 
	{
		return false;
	}
	MyJson pJson;
	if(!pJson.parse(rstr)) 
	{
		return false;
	}

	int errcode = -1;
        if(!pJson.getInt("errcode", errcode) || errcode!=0) 
	{
		return false;
	}

	Json::Value dataObj;
	if(!pJson.getObject("data", dataObj));
	MyJson pDataObjJson(dataObj);
	
	std::string file_path;
	if(!pDataObjJson.getString("filepath", file_path))
	{
		return false;
	}

	int pos = file_path.find_last_of("/");
	std::string path_str = file_path.substr(0, pos);
	if(access(path_str.data(), NULL) != 0)
	{
		CreateDir(path_str.data());
	}

	std::string file_buf;
	if(!pDataObjJson.getString("content", file_buf))
	{
		return false;
	}

	FILE *fp = fopen(file_path.data(), "w+");
	if(!fp) return false;
	fwrite(file_buf.data(), 1, file_buf.size(), fp);
	fclose(fp);
	
	//get file md5
	std::string mv_cmd = "mv " + file_path + " " + file_path + "_bak";
	system(mv_cmd.data());
	root["md5"] = Json::Value(MD5().fileDigest(file_path));
	pstr = fast_writer.write(root);
	if(Post(check_url, pstr, rstr) != CURLE_OK) 
	{
		mv_cmd = "mv " + file_path + "_bak " + file_path;
                system(mv_cmd.data());
		return false;
	}
	if(!pJson.parse(rstr)) return false;
	int res_code = -1;
	if(!pJson.getInt("errcode", res_code) || res_code!=0)
	{
		mv_cmd = "mv " + file_path + "_bak " + file_path;
		system(mv_cmd.data());
		return false;
	}
	return true;
}

bool MogoCurl::DownloadFileContentImpl(const std::string &update_url, const std::string &download_url, const std::string &check_url, const std::string &mac_addr, const std::string &SN)
{
	bool flag = true;
	std::list<std::string> file_list;
	if(!GetUpdateFileList(update_url, mac_addr, SN, file_list)) return false;
	
	for(auto it=file_list.begin(); it!=file_list.end(); it++)
	{
		if(!DownloadFileContent(download_url, check_url, SN, mac_addr, *it))
		{
			flag = false;
		}
	}
	return flag;
}

std::string MogoCurl::GetPlate()
{
	std::ifstream fin("/home/mogo/data/vehicle_monitor/vehicle_config.txt");
	if(!fin.is_open())
	{
		return "";
	}
	std::string line;
	while(std::getline(fin, line))
	{
		int pos = line.find(":", 0);
		if(pos==std::string::npos)
		{
			continue;
		}
		std::string key = line.substr(0, pos);
		if(key.find("plate") == std::string::npos)
		{
			continue;	
		}
		std::string value = line.substr(line.find_first_of("\"")+1, line.find_last_of("\""));
		return value;
	}
	return "";
}
