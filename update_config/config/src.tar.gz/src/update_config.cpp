//#include <ros/ros.h>

#include "mogo_curl.h"

bool UpdatePbFile()
{
	MogoCurl *pCurl = new MogoCurl;
	pCurl->Init();
	std::string url1 = "172.30.36.89:2222/config/driver/list";
	std::string url2 = "172.30.36.89:2222/config/driver/pull";
	std::string url3 = "172.30.36.89:2222/config/driver/sync";
	std::string SN = pCurl->GetPlate();
	char szMac[18];
	int nRtn = get_mac(szMac, sizeof(szMac));
	bool flag = true;
	flag = pCurl->DownloadFileContentImpl(url1, url2, url3, szMac, SN);
	if(flag == false)
	{
		int times = 0;
		while(times++<5)
		{
			flag = pCurl->DownloadFileContentImpl(url1, url2, url3, szMac, SN);
			if(flag ==true) break;
		}
	}
	delete pCurl;
	return flag;
}

int main(int argc, char **argv)
{
    bool flag = UpdatePbFile();
    std::cout << "update pb file success" << flag << std::endl;
    return 0;
}
